"""
AutoShield - Auto-Block Module
Fires iptables rules to block attacker IPs automatically.
Falls back to in-process blocklist when not root (dev mode).
"""

import subprocess
import logging
import threading
import json
import time
import os
from datetime import datetime, timedelta
from collections import defaultdict

log = logging.getLogger("AutoShield.Blocker")

# ─── Config ───────────────────────────────────────────────────────────────────

BLOCK_DURATION_SECONDS = 3600       # 1 hour auto-expiry
RATE_LIMIT_WINDOW      = 60         # seconds
RATE_LIMIT_THRESHOLD   = 5          # attacks before rate-ban
WHITELIST_IPS          = {"127.0.0.1", "::1"}   # never block these


# ─── iptables helpers ─────────────────────────────────────────────────────────

def _is_root() -> bool:
    return os.geteuid() == 0 if hasattr(os, "geteuid") else False


def _iptables(action: str, ip: str) -> tuple[bool, str]:
    """
    action: 'block' | 'unblock'
    Returns (success, message)
    """
    flag = "-A" if action == "block" else "-D"
    cmd  = ["iptables", flag, "INPUT", "-s", ip, "-j", "DROP"]
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return True, f"iptables {action} {ip} OK"
        else:
            return False, f"iptables error: {result.stderr.strip()}"
    except FileNotFoundError:
        return False, "iptables not found (not Linux or not installed)"
    except subprocess.TimeoutExpired:
        return False, "iptables command timed out"
    except Exception as e:
        return False, str(e)


# ─── Block Manager ────────────────────────────────────────────────────────────

class BlockManager:
    """
    Tracks blocked IPs, fires iptables rules when root,
    else maintains in-memory blocklist for dev/demo mode.
    """

    def __init__(self):
        self._blocked: dict[str, dict] = {}     # ip → block_record
        self._attack_counts: dict[str, list]    = defaultdict(list)  # ip → [timestamps]
        self._lock = threading.RLock()
        self._root = _is_root()

        if not self._root:
            log.warning("Not running as root — iptables disabled. Using in-memory blocklist.")

        # Start expiry cleanup thread
        self._expiry_thread = threading.Thread(target=self._expiry_loop, daemon=True)
        self._expiry_thread.start()

    # ── public API ──────────────────────────────────────────────────────────

    def block_ip(self, ip: str, reason: str = "attack detected",
                 severity: str = "HIGH", attack_type: str = "Unknown") -> dict:
        """Block an IP. Returns block record."""
        if ip in WHITELIST_IPS:
            return {"status": "SKIPPED", "reason": "IP is whitelisted", "ip": ip}

        with self._lock:
            if ip in self._blocked:
                return {"status": "ALREADY_BLOCKED", "ip": ip, **self._blocked[ip]}

            expires_at = datetime.now() + timedelta(seconds=BLOCK_DURATION_SECONDS)
            record = {
                "ip":          ip,
                "reason":      reason,
                "attack_type": attack_type,
                "severity":    severity,
                "blocked_at":  datetime.now().isoformat(),
                "expires_at":  expires_at.isoformat(),
                "method":      "iptables" if self._root else "in-memory",
                "status":      "BLOCKED",
            }

            # Fire iptables if root
            if self._root:
                ok, msg = _iptables("block", ip)
                if not ok:
                    record["status"]  = "BLOCK_FAILED"
                    record["error"]   = msg
                    log.error(f"Failed to block {ip}: {msg}")
                    return record
                record["iptables_msg"] = msg

            self._blocked[ip] = record
            log.warning(
                f"🚫 BLOCKED {ip} | {attack_type} [{severity}] "
                f"| expires {expires_at.strftime('%H:%M:%S')} "
                f"| method={record['method']}"
            )
            return record

    def unblock_ip(self, ip: str) -> dict:
        with self._lock:
            if ip not in self._blocked:
                return {"status": "NOT_BLOCKED", "ip": ip}

            record = self._blocked.pop(ip)

            if self._root:
                ok, msg = _iptables("unblock", ip)
                if not ok:
                    log.error(f"Failed to unblock {ip}: {msg}")

            log.info(f"✅ UNBLOCKED {ip}")
            return {"status": "UNBLOCKED", "ip": ip, "was": record}

    def is_blocked(self, ip: str) -> bool:
        with self._lock:
            return ip in self._blocked

    def get_blocked_list(self) -> list[dict]:
        with self._lock:
            return list(self._blocked.values())

    def record_attack(self, ip: str) -> bool:
        """
        Track attack rate per IP.
        Returns True if rate-limit threshold exceeded → caller should block.
        """
        now = time.time()
        with self._lock:
            # Prune old timestamps
            self._attack_counts[ip] = [
                t for t in self._attack_counts[ip]
                if now - t < RATE_LIMIT_WINDOW
            ]
            self._attack_counts[ip].append(now)
            count = len(self._attack_counts[ip])

        if count >= RATE_LIMIT_THRESHOLD:
            log.warning(f"Rate limit hit for {ip}: {count} attacks in {RATE_LIMIT_WINDOW}s")
            return True
        return False

    def auto_respond(self, event: dict) -> dict:
        """
        Full auto-defense pipeline for an attack event.
        Returns enriched event with action taken.
        """
        ip          = event.get("src_ip", "0.0.0.0")
        attack_type = event.get("attack_type", "Unknown")
        severity    = event.get("severity", "HIGH")

        # Always block CRITICAL; rate-limit for others
        should_block = (
            severity == "CRITICAL"
            or self.record_attack(ip)
        )

        if should_block:
            record = self.block_ip(
                ip,
                reason=f"Auto-blocked: {attack_type}",
                severity=severity,
                attack_type=attack_type,
            )
            event["action"]   = "BLOCKED"
            event["status"]   = "MITIGATED"
            event["block_record"] = record
        else:
            event["action"] = "RATE_MONITORED"
            event["status"] = "MONITORING"

        # Input sanitization note (applied at WAF layer in real deploy)
        event["sanitization"] = _sanitize_note(attack_type)

        return event

    # ── expiry loop ─────────────────────────────────────────────────────────

    def _expiry_loop(self):
        while True:
            time.sleep(30)
            now = datetime.now()
            with self._lock:
                expired = [
                    ip for ip, rec in self._blocked.items()
                    if datetime.fromisoformat(rec["expires_at"]) <= now
                ]
            for ip in expired:
                log.info(f"Auto-expiring block for {ip}")
                self.unblock_ip(ip)

    def flush_all(self):
        """Emergency: unblock all IPs."""
        ips = list(self._blocked.keys())
        for ip in ips:
            self.unblock_ip(ip)
        log.info(f"Flushed {len(ips)} blocked IPs.")

    def stats(self) -> dict:
        with self._lock:
            return {
                "total_blocked":  len(self._blocked),
                "attack_counters": {
                    ip: len(ts) for ip, ts in self._attack_counts.items()
                },
                "root_mode": self._root,
            }


# ─── Input Sanitization Advice ────────────────────────────────────────────────

def _sanitize_note(attack_type: str) -> str:
    NOTES = {
        "SQLi": "Parameterized queries applied. Input stripped of SQL metacharacters.",
        "XSS":  "HTML-encoded output. Script tags neutralized.",
        "LFI":  "Path traversal stripped. File access restricted to allowed dir.",
        "CMDi": "Shell metacharacters removed. Command execution sandboxed.",
    }
    return NOTES.get(attack_type, "Input sanitized.")


# ─── Singleton ────────────────────────────────────────────────────────────────

_blocker_instance: BlockManager | None = None

def get_blocker() -> BlockManager:
    global _blocker_instance
    if _blocker_instance is None:
        _blocker_instance = BlockManager()
    return _blocker_instance


# ─── Quick test ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    blocker = BlockManager()

    test_event = {
        "src_ip":      "192.168.1.99",
        "attack_type": "SQLi",
        "severity":    "CRITICAL",
    }

    print("=== AutoShield Blocker Self-Test ===\n")
    result = blocker.auto_respond(test_event)
    print(json.dumps(result, indent=2, default=str))

    print(f"\nBlocked list: {blocker.get_blocked_list()}")
    print(f"Stats: {blocker.stats()}")

    time.sleep(1)
    print(f"\nUnblocking...")
    blocker.unblock_ip("192.168.1.99")
    print(f"Blocked list after unblock: {blocker.get_blocked_list()}")
