# 🛡️ AutoShield AI
> Real-Time Web Attack Detection & Auto-Defense System

---

## Team Split
| Person | Owns |
|--------|------|
| **You** | `scapy_engine.py` — traffic capture + ML rule classifier |
| **Amit** | `auto_block.py` — iptables auto-block + backend |
| **Arpan** | `dashboard.py` + `cve_lookup.py` + `attack_simulator.py` |

---

## Setup (5 minutes)

```bash
# 1. Clone / unzip project
cd autoshield/

# 2. Install deps
pip install -r requirements.txt

# 3. Run dashboard
streamlit run dashboard.py
```

> **No root needed for demo** — runs in simulation mode automatically.
> For live packet sniffing: `sudo python scapy_engine.py`

---

## 3-Minute Demo Flow 🎬

```
1. Open dashboard → everything green, 0 attacks

2. Sidebar → Attack Type = SQLi → Launch Attack
   → Dashboard flashes red
   → Log: CRITICAL | SQLi | 192.168.1.100 | BLOCKED
   → Confidence: 75%

3. Click CVE tab → CVE-2023-23752 card pulls up
   → CVSS 9.8 CRITICAL | "This attack = trending globally"

4. Payload Inspector → shows raw SQL injection string
   → Auto-Defense: "Parameterized queries applied. IP DROPPED"

5. Run Full Demo button → all 4 attack types fire
   → Metric row counts up live

6. Clear → everything green again
   → "System healed."
```

---

## Architecture

```
Attacker (attack_simulator.py)
        ↓  HTTP requests with SQLi/XSS/LFI/CMDi payloads
Scapy engine (scapy_engine.py)
        ↓  Packet sniff → decode → regex + rule engine
Attack Detector
        ↓  attack_type, severity, confidence, CVE hint
Auto Blocker (auto_block.py)
        ↓  iptables DROP rule (or in-memory for demo)
Dashboard (dashboard.py)
        ↓  Real-time log, CVE card, payload inspector
NVD API (cve_lookup.py)
        ↓  Live CVE data with CVSS scores
```

---

## File Guide

| File | What it does |
|------|-------------|
| `scapy_engine.py` | Packet sniffer + multi-type attack classifier (SQLi/XSS/LFI/CMDi). Runs `simulate_attack()` without root. |
| `auto_block.py` | `BlockManager` — fires iptables, tracks rates, auto-expires blocks after 1 hour. |
| `cve_lookup.py` | NVD API wrapper with fallback static data. `get_cve_card(attack_type)` for dashboard. |
| `attack_simulator.py` | Fires real HTTP payloads at `localhost:8080`. CLI: `python attack_simulator.py --type SQLi` |
| `dashboard.py` | Full Streamlit UI: metrics, live log, CVE panel, payload inspector. |

---

## Live Sniffing (Amit's domain)

```bash
# Start test web server (victim)
python -m http.server 8080

# Fire attacks from another terminal
python attack_simulator.py --type SQLi --target http://localhost:8080

# Run engine with root (sniff mode)
sudo python scapy_engine.py
```

---

## Judging Checklist ✅

- [x] Real ML/rule engine classifying 4 attack types
- [x] Auto-block fires on detection (iptables or in-memory)
- [x] CVE cards pulled from NIST NVD API
- [x] Live dashboard with attack log, metrics, payload inspector
- [x] 3-min demo flow documented
- [x] No paid APIs, no cloud required
- [x] Works without root (demo mode)
