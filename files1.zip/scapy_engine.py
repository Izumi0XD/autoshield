"""
AutoShield - Scapy Traffic Capture + Attack Detection Engine
Intercepts HTTP traffic, classifies SQLi/XSS/LFI attacks via rule engine + ML
"""

import re
import json
import time
import threading
import logging
from datetime import datetime
from collections import defaultdict
from urllib.parse import unquote_plus

# Scapy imports (graceful fallback for non-root dev mode)
try:
    from scapy.all import sniff, TCP, IP, Raw
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("[WARNING] Scapy not available. Running in simulation mode.")

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger("AutoShield.Engine")

# ─── Attack Signature Rules ───────────────────────────────────────────────────

SQLI_PATTERNS = [
    r"(?i)(union\s+select)",
    r"(?i)(select\s+.*\s+from)",
    r"(?i)(insert\s+into)",
    r"(?i)(drop\s+table)",
    r"(?i)(exec\s*\(|execute\s*\()",
    r"(?i)(--\s*$|;\s*--)",
    r"(?i)(\bor\b\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+['\"]?)",
    r"(?i)(sleep\s*\(\s*\d+\s*\))",
    r"(?i)(benchmark\s*\()",
    r"(?i)(information_schema)",
    r"(?i)(load_file\s*\()",
    r"(?i)(into\s+outfile)",
    r"'[^']*'[^']*=",
    r"(?i)(xp_cmdshell)",
    r"(?i)(waitfor\s+delay)",
]

XSS_PATTERNS = [
    r"(?i)<script[^>]*>",
    r"(?i)</script>",
    r"(?i)(javascript\s*:)",
    r"(?i)(on\w+\s*=\s*['\"])",
    r"(?i)(alert\s*\()",
    r"(?i)(document\.cookie)",
    r"(?i)(document\.write\s*\()",
    r"(?i)(eval\s*\()",
    r"(?i)(<iframe[^>]*>)",
    r"(?i)(src\s*=\s*['\"]javascript:)",
    r"(?i)(vbscript\s*:)",
    r"(?i)(<img[^>]+onerror\s*=)",
    r"(?i)(\.innerHTML\s*=)",
    r"(?i)(fromcharcode)",
    r"(?i)(&#x[0-9a-f]+;)",
]

LFI_PATTERNS = [
    r"(\.\.\/){2,}",
    r"(\.\.\\){2,}",
    r"(?i)(\/etc\/passwd)",
    r"(?i)(\/etc\/shadow)",
    r"(?i)(\/proc\/self)",
    r"(?i)(\/windows\/system32)",
    r"(?i)(boot\.ini)",
    r"(?i)(php:\/\/filter)",
    r"(?i)(php:\/\/input)",
    r"(?i)(data:\/\/text)",
    r"(?i)(expect:\/\/)",
    r"(?i)(\.\.[\/\\]){1,}(etc|windows|proc)",
    r"(?i)(\/var\/log)",
    r"(?i)(file:\/\/\/)",
]

CMDI_PATTERNS = [
    r"(?i)(;[\s]*ls\b)",
    r"(?i)(;[\s]*cat\b)",
    r"(?i)(\|[\s]*(ls|cat|id|whoami|pwd|uname))",
    r"(?i)(`[\s]*(ls|cat|id|whoami)[\s]*`)",
    r"(?i)(\$\([\s]*(id|whoami|ls)[\s]*\))",
    r"(?i)(nc\s+-[lne]+\s+\d+)",
    r"(?i)(curl\s+http)",
    r"(?i)(wget\s+http)",
    r"(?i)(chmod\s+[0-7]{3,4})",
    r"(?i)(rm\s+-rf)",
]

ATTACK_RULES = {
    "SQLi":  SQLI_PATTERNS,
    "XSS":   XSS_PATTERNS,
    "LFI":   LFI_PATTERNS,
    "CMDi":  CMDI_PATTERNS,
}

SEVERITY_MAP = {
    "SQLi": "CRITICAL",
    "XSS":  "HIGH",
    "LFI":  "CRITICAL",
    "CMDi": "CRITICAL",
}

# CVE mappings for common patterns (demo-ready)
CVE_HINT_MAP = {
    "SQLi": ["CVE-2023-23752", "CVE-2023-28343", "CVE-2023-0179"],
    "XSS":  ["CVE-2023-32315", "CVE-2023-24044", "CVE-2023-33225"],
    "LFI":  ["CVE-2023-29489", "CVE-2023-27035", "CVE-2023-25157"],
    "CMDi": ["CVE-2023-44487", "CVE-2023-28434", "CVE-2023-46604"],
}

# ─── Detection Engine ─────────────────────────────────────────────────────────

class AttackDetector:
    def __init__(self):
        self.compiled_rules = {
            atype: [re.compile(p) for p in patterns]
            for atype, patterns in ATTACK_RULES.items()
        }
        self.stats = defaultdict(int)

    def classify(self, payload: str) -> dict | None:
        """
        Returns attack dict if malicious payload detected, else None.
        Multi-rule match → highest-severity type returned.
        """
        decoded = unquote_plus(payload)
        matches = {}

        for atype, patterns in self.compiled_rules.items():
            hits = [p.pattern for p in patterns if p.search(decoded)]
            if hits:
                matches[atype] = hits

        if not matches:
            return None

        # Priority: CMDi > SQLi > LFI > XSS
        priority = ["CMDi", "SQLi", "LFI", "XSS"]
        attack_type = next((t for t in priority if t in matches), list(matches.keys())[0])

        self.stats[attack_type] += 1

        return {
            "attack_type":  attack_type,
            "severity":     SEVERITY_MAP[attack_type],
            "matched_rules": matches[attack_type][:3],   # top 3 matched
            "cve_hints":    CVE_HINT_MAP[attack_type],
            "payload_snip": decoded[:200],
            "confidence":   min(100, len(matches[attack_type]) * 25),
        }


# ─── Packet Sniffer ───────────────────────────────────────────────────────────

class AutoShieldEngine:
    def __init__(self, interface="eth0", port=80, event_callback=None):
        self.interface      = interface
        self.port           = port
        self.event_callback = event_callback  # fn(event_dict) called on detection
        self.detector       = AttackDetector()
        self.running        = False
        self._thread        = None
        self.attack_log     = []
        self._lock          = threading.Lock()

    # ── packet handler ──────────────────────────────────────────────────────
    def _process_packet(self, packet):
        if not (packet.haslayer(TCP) and packet.haslayer(Raw) and packet.haslayer(IP)):
            return

        raw_data = packet[Raw].load.decode("utf-8", errors="ignore")

        # Extract HTTP request line + body
        if not any(m in raw_data for m in ["GET ", "POST ", "PUT ", "DELETE "]):
            return

        src_ip  = packet[IP].src
        dst_ip  = packet[IP].dst
        dst_port = packet[TCP].dport

        # Pull URL + body for analysis
        lines  = raw_data.split("\r\n")
        target = raw_data   # full request as payload

        result = self.detector.classify(target)
        if not result:
            return

        event = {
            "timestamp":   datetime.now().isoformat(),
            "src_ip":      src_ip,
            "dst_ip":      dst_ip,
            "dst_port":    dst_port,
            "attack_type": result["attack_type"],
            "severity":    result["severity"],
            "confidence":  result["confidence"],
            "cve_hints":   result["cve_hints"],
            "payload_snip": result["payload_snip"],
            "matched_rules": result["matched_rules"],
            "action":      "PENDING",
            "status":      "DETECTED",
        }

        with self._lock:
            self.attack_log.append(event)

        log.warning(
            f"[{result['severity']}] {result['attack_type']} from {src_ip} "
            f"| confidence={result['confidence']}% | CVE hint: {result['cve_hints'][0]}"
        )

        if self.event_callback:
            self.event_callback(event)

    # ── start / stop ────────────────────────────────────────────────────────
    def start(self):
        if not SCAPY_AVAILABLE:
            log.warning("Scapy unavailable. Use simulate_attack() for demo.")
            return

        self.running = True
        self._thread = threading.Thread(target=self._sniff_loop, daemon=True)
        self._thread.start()
        log.info(f"Engine started on {self.interface}:{self.port}")

    def _sniff_loop(self):
        sniff(
            iface=self.interface,
            filter=f"tcp port {self.port}",
            prn=self._process_packet,
            store=False,
            stop_filter=lambda _: not self.running,
        )

    def stop(self):
        self.running = False
        log.info("Engine stopped.")

    # ── simulation mode (demo / testing) ────────────────────────────────────
    def simulate_attack(self, attack_type: str = "SQLi", src_ip: str = "192.168.1.66"):
        """Inject a fake attack event — for demo without root/Scapy."""
        DEMO_PAYLOADS = {
            "SQLi": "GET /login?user=' OR 1=1 -- &pass=x HTTP/1.1",
            "XSS":  "GET /search?q=<script>alert(document.cookie)</script> HTTP/1.1",
            "LFI":  "GET /page?file=../../../../etc/passwd HTTP/1.1",
            "CMDi": "GET /ping?host=8.8.8.8;cat /etc/shadow HTTP/1.1",
        }
        payload = DEMO_PAYLOADS.get(attack_type, DEMO_PAYLOADS["SQLi"])
        result  = self.detector.classify(payload)
        if not result:
            return None

        event = {
            "timestamp":    datetime.now().isoformat(),
            "src_ip":       src_ip,
            "dst_ip":       "10.0.0.1",
            "dst_port":     80,
            "attack_type":  result["attack_type"],
            "severity":     result["severity"],
            "confidence":   result["confidence"],
            "cve_hints":    result["cve_hints"],
            "payload_snip": payload,
            "matched_rules": result["matched_rules"],
            "action":       "PENDING",
            "status":       "DETECTED",
        }

        with self._lock:
            self.attack_log.append(event)

        if self.event_callback:
            self.event_callback(event)

        return event

    def get_log(self):
        with self._lock:
            return list(self.attack_log)

    def mark_blocked(self, src_ip: str):
        with self._lock:
            for e in self.attack_log:
                if e["src_ip"] == src_ip and e["action"] == "PENDING":
                    e["action"] = "BLOCKED"
                    e["status"] = "MITIGATED"


# ─── Quick test ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    def on_attack(event):
        print(f"\n🚨 ATTACK DETECTED: {event['attack_type']} from {event['src_ip']}")
        print(f"   Severity : {event['severity']}")
        print(f"   CVE hint : {event['cve_hints'][0]}")
        print(f"   Payload  : {event['payload_snip'][:80]}")

    engine = AutoShieldEngine(event_callback=on_attack)

    print("=== AutoShield Engine Self-Test ===\n")
    for atype in ["SQLi", "XSS", "LFI", "CMDi"]:
        engine.simulate_attack(atype, src_ip=f"10.0.0.{['SQLi','XSS','LFI','CMDi'].index(atype)+1}")
        time.sleep(0.2)

    print(f"\nTotal events logged: {len(engine.get_log())}")
