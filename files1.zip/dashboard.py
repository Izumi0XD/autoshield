"""
AutoShield — Real-Time Attack Detection Dashboard
Run: streamlit run dashboard.py
"""

import streamlit as st
import pandas as pd
import time
import threading
from datetime import datetime

# ── Local modules ─────────────────────────────────────────────────────────────
from scapy_engine import AutoShieldEngine
from auto_block   import BlockManager
from cve_lookup   import get_cve_card, _fallback_cves

# ─── Page config ──────────────────────────────────────────────────────────────

st.set_page_config(
    page_title  = "AutoShield AI",
    page_icon   = "🛡️",
    layout      = "wide",
    initial_sidebar_state = "expanded",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────

st.markdown("""
<style>
  /* Dark theme base */
  .stApp { background-color: #0d1117; color: #e6edf3; }

  /* Metric cards */
  .metric-card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 16px;
    text-align: center;
  }
  .metric-big   { font-size: 2.4rem; font-weight: 700; }
  .metric-label { font-size: 0.85rem; color: #8b949e; margin-top: 4px; }

  /* Attack severity badges */
  .badge-CRITICAL { background:#b91c1c; color:#fff; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600; }
  .badge-HIGH     { background:#d97706; color:#fff; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600; }
  .badge-MEDIUM   { background:#2563eb; color:#fff; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600; }
  .badge-BLOCKED  { background:#16a34a; color:#fff; padding:2px 8px; border-radius:4px; font-size:0.75rem; }

  /* Attack type colors */
  .attack-SQLi { color: #f87171; }
  .attack-XSS  { color: #fbbf24; }
  .attack-LFI  { color: #a78bfa; }
  .attack-CMDi { color: #f97316; }

  /* CVE card */
  .cve-card {
    background: #161b22;
    border: 1px solid #f87171;
    border-left: 4px solid #f87171;
    border-radius: 8px;
    padding: 16px;
    margin: 8px 0;
  }
  .cve-id     { font-size: 1.1rem; font-weight: 700; color: #f87171; }
  .cve-score  { font-size: 2rem; font-weight: 700; }
  .cve-desc   { font-size: 0.85rem; color: #8b949e; margin-top: 8px; }

  /* Status indicator */
  .status-green { color: #22c55e; font-weight: 700; font-size: 1.1rem; }
  .status-red   { color: #ef4444; font-weight: 700; font-size: 1.1rem; animation: pulse 1s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }

  /* Log table */
  .log-row { border-bottom: 1px solid #21262d; padding: 6px 0; font-size: 0.82rem; }

  /* Header */
  .shield-header {
    background: linear-gradient(135deg, #1a1f2e 0%, #0d1117 100%);
    border: 1px solid #30363d;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 20px;
  }
  .shield-title { font-size: 1.8rem; font-weight: 800; }

  div[data-testid="stButton"] button {
    border-radius: 6px;
    font-weight: 600;
  }
</style>
""", unsafe_allow_html=True)


# ─── Session state init ───────────────────────────────────────────────────────

def _init_state():
    if "engine"  not in st.session_state:
        st.session_state.engine  = AutoShieldEngine()
    if "blocker" not in st.session_state:
        st.session_state.blocker = BlockManager()
    if "attack_log" not in st.session_state:
        st.session_state.attack_log = []
    if "system_status" not in st.session_state:
        st.session_state.system_status = "MONITORING"
    if "selected_cve_type" not in st.session_state:
        st.session_state.selected_cve_type = None
    if "last_attack" not in st.session_state:
        st.session_state.last_attack = None

_init_state()
engine  = st.session_state.engine
blocker = st.session_state.blocker

# Sync log from engine
def sync_log():
    st.session_state.attack_log = engine.get_log()

# ─── Header ───────────────────────────────────────────────────────────────────

col_logo, col_status, col_time = st.columns([3, 2, 2])

with col_logo:
    st.markdown("""
    <div class="shield-header">
      <div class="shield-title">🛡️ AutoShield AI</div>
      <div style="color:#8b949e; font-size:0.85rem; margin-top:4px;">
        Real-Time Web Attack Detection &amp; Auto-Defense System
      </div>
    </div>
    """, unsafe_allow_html=True)

with col_status:
    sync_log()
    log_data      = st.session_state.attack_log
    unmitigated   = [e for e in log_data if e.get("status") != "MITIGATED"]
    system_status = "🔴 UNDER ATTACK" if unmitigated else "🟢 ALL SYSTEMS SECURE"
    status_class  = "status-red" if unmitigated else "status-green"
    st.markdown(f"""
    <div style="padding-top:28px">
      <div class="{status_class}">{system_status}</div>
      <div style="color:#8b949e;font-size:0.8rem;margin-top:4px;">
        {len(blocker.get_blocked_list())} IPs currently blocked
      </div>
    </div>
    """, unsafe_allow_html=True)

with col_time:
    st.markdown(f"""
    <div style="padding-top:28px; text-align:right; color:#8b949e; font-size:0.82rem;">
      Last refresh<br/>
      <span style="color:#e6edf3">{datetime.now().strftime('%H:%M:%S')}</span>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

# ─── Sidebar: Controls ────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("### ⚙️ Controls")

    st.markdown("#### 🎯 Simulate Attack")
    attack_type = st.selectbox(
        "Attack Type",
        ["SQLi", "XSS", "LFI", "CMDi"],
        key="attack_selector"
    )
    src_ip = st.text_input("Source IP", value="192.168.1.100")

    if st.button("🚀 Launch Attack", type="primary", use_container_width=True):
        event = engine.simulate_attack(attack_type=attack_type, src_ip=src_ip)
        if event:
            # Auto-respond (block)
            blocker.auto_respond(event)
            engine.mark_blocked(src_ip)
            st.session_state.last_attack   = event
            st.session_state.selected_cve_type = attack_type
            sync_log()
            st.success(f"Attack fired! {attack_type} from {src_ip}")
            st.rerun()

    st.markdown("---")

    st.markdown("#### 🔥 Rapid Demo (all types)")
    if st.button("Run Full Demo", use_container_width=True):
        ips = {
            "SQLi": "10.0.0.11",
            "XSS":  "10.0.0.12",
            "LFI":  "10.0.0.13",
            "CMDi": "10.0.0.14",
        }
        for atype, ip in ips.items():
            ev = engine.simulate_attack(atype, src_ip=ip)
            if ev:
                blocker.auto_respond(ev)
                engine.mark_blocked(ip)
        st.session_state.selected_cve_type = "SQLi"
        sync_log()
        st.rerun()

    st.markdown("---")
    st.markdown("#### 🧹 Reset")
    if st.button("Clear All Logs", use_container_width=True):
        engine.attack_log.clear()
        blocker.flush_all()
        st.session_state.attack_log        = []
        st.session_state.last_attack       = None
        st.session_state.selected_cve_type = None
        st.rerun()

    st.markdown("---")
    st.markdown("#### 🔄 Auto-Refresh")
    auto_refresh = st.toggle("Auto-refresh (5s)", value=False)
    if auto_refresh:
        time.sleep(5)
        st.rerun()

# ─── Metric Row ───────────────────────────────────────────────────────────────

sync_log()
log_data = st.session_state.attack_log

total_attacks  = len(log_data)
blocked_count  = len([e for e in log_data if e.get("action") == "BLOCKED"])
sqli_count     = len([e for e in log_data if e.get("attack_type") == "SQLi"])
xss_count      = len([e for e in log_data if e.get("attack_type") == "XSS"])
lfi_count      = len([e for e in log_data if e.get("attack_type") == "LFI"])
cmdi_count     = len([e for e in log_data if e.get("attack_type") == "CMDi"])

m1, m2, m3, m4, m5, m6 = st.columns(6)

def metric_card(container, value, label, color="#e6edf3"):
    container.markdown(f"""
    <div class="metric-card">
      <div class="metric-big" style="color:{color}">{value}</div>
      <div class="metric-label">{label}</div>
    </div>
    """, unsafe_allow_html=True)

metric_card(m1, total_attacks, "Total Attacks",  "#60a5fa")
metric_card(m2, blocked_count, "Blocked",         "#22c55e")
metric_card(m3, sqli_count,    "SQLi",            "#f87171")
metric_card(m4, xss_count,     "XSS",             "#fbbf24")
metric_card(m5, lfi_count,     "LFI",             "#a78bfa")
metric_card(m6, cmdi_count,    "CMDi",            "#f97316")

st.markdown("<br/>", unsafe_allow_html=True)

# ─── Main 2-column layout ─────────────────────────────────────────────────────

col_log, col_cve = st.columns([3, 2])

# ── Attack Log ────────────────────────────────────────────────────────────────

with col_log:
    st.markdown("### 📋 Live Attack Log")

    if not log_data:
        st.markdown("""
        <div style="background:#161b22;border:1px dashed #30363d;border-radius:8px;
             padding:40px;text-align:center;color:#8b949e;">
          🟢 No attacks detected. System is clean.<br/>
          <small>Use the sidebar to simulate an attack.</small>
        </div>
        """, unsafe_allow_html=True)
    else:
        # Table header
        h1,h2,h3,h4,h5,h6 = st.columns([1.4, 1.5, 1.2, 1.2, 1.2, 1.0])
        for h, label in zip([h1,h2,h3,h4,h5,h6],
                             ["Time","Source IP","Type","Severity","Action","Conf."]):
            h.markdown(f"<small style='color:#8b949e'><b>{label}</b></small>", unsafe_allow_html=True)

        for event in reversed(log_data[-30:]):   # latest 30, newest first
            c1,c2,c3,c4,c5,c6 = st.columns([1.4, 1.5, 1.2, 1.2, 1.2, 1.0])
            ts        = event.get("timestamp","")[-8:-3]    # HH:MM
            src_ip_ev = event.get("src_ip","-")
            atype     = event.get("attack_type","-")
            sev       = event.get("severity","-")
            action    = event.get("action","PENDING")
            conf      = event.get("confidence",0)

            sev_color    = {"CRITICAL":"#f87171","HIGH":"#fbbf24","MEDIUM":"#60a5fa"}.get(sev,"#e6edf3")
            action_color = {"BLOCKED":"#22c55e","RATE_MONITORED":"#fbbf24","PENDING":"#8b949e"}.get(action,"#e6edf3")
            type_color   = {"SQLi":"#f87171","XSS":"#fbbf24","LFI":"#a78bfa","CMDi":"#f97316"}.get(atype,"#e6edf3")

            c1.markdown(f"<small>{ts}</small>", unsafe_allow_html=True)
            c2.markdown(f"<small style='font-family:monospace'>{src_ip_ev}</small>", unsafe_allow_html=True)
            c3.markdown(f"<small style='color:{type_color};font-weight:600'>{atype}</small>", unsafe_allow_html=True)
            c4.markdown(f"<small style='color:{sev_color}'>{sev}</small>", unsafe_allow_html=True)
            c5.markdown(f"<small style='color:{action_color}'>{action}</small>", unsafe_allow_html=True)
            c6.markdown(f"<small>{conf}%</small>", unsafe_allow_html=True)

    # Blocked IPs section
    st.markdown("<br/>", unsafe_allow_html=True)
    st.markdown("### 🚫 Blocked IPs")
    blocked_ips = blocker.get_blocked_list()

    if not blocked_ips:
        st.markdown("<small style='color:#8b949e'>No IPs currently blocked.</small>", unsafe_allow_html=True)
    else:
        for b in blocked_ips:
            b1, b2, b3, b4 = st.columns([1.5, 1.2, 1.5, 1.0])
            b1.markdown(f"<small style='font-family:monospace;color:#f87171'>{b['ip']}</small>", unsafe_allow_html=True)
            b2.markdown(f"<small style='color:#fbbf24'>{b['attack_type']}</small>", unsafe_allow_html=True)
            b3.markdown(f"<small style='color:#8b949e'>exp: {b['expires_at'][-8:-3]}</small>", unsafe_allow_html=True)
            if b4.button("Unblock", key=f"unblock_{b['ip']}"):
                blocker.unblock_ip(b["ip"])
                st.rerun()


# ── CVE Panel ─────────────────────────────────────────────────────────────────

with col_cve:
    st.markdown("### 🔍 CVE Intelligence")

    # CVE type selector
    cve_type = st.radio(
        "Attack type",
        ["SQLi", "XSS", "LFI", "CMDi"],
        horizontal=True,
        index=["SQLi","XSS","LFI","CMDi"].index(
            st.session_state.selected_cve_type or "SQLi"
        ),
        key="cve_type_radio"
    )
    st.session_state.selected_cve_type = cve_type

    # Load CVE data
    with st.spinner("Loading CVE data..."):
        cve_data = get_cve_card(cve_type)

    top_cve = cve_data
    all_cves = cve_data.get("all_cves", [cve_data])

    score = top_cve.get("cvss_score", "N/A")
    score_color = "#f87171" if isinstance(score, (int,float)) and score >= 9 else \
                  "#fbbf24" if isinstance(score, (int,float)) and score >= 7 else "#60a5fa"

    # Top CVE card
    st.markdown(f"""
    <div class="cve-card">
      <div class="cve-id">{top_cve.get('cve_id','N/A')}</div>
      <div style="display:flex; align-items:center; gap:12px; margin-top:8px">
        <div>
          <div class="cve-score" style="color:{score_color}">{score}</div>
          <div style="font-size:0.75rem;color:#8b949e">CVSS Score</div>
        </div>
        <div>
          <span class="badge-{top_cve.get('severity','UNKNOWN')}">{top_cve.get('severity','UNKNOWN')}</span><br/>
          <span style="font-size:0.75rem;color:#8b949e;margin-top:4px;display:block">
            Published: {top_cve.get('published','N/A')}
          </span>
        </div>
      </div>
      <div class="cve-desc">{top_cve.get('description','')[:200]}...</div>
      {"<a href='" + top_cve.get('reference','') + "' target='_blank' style='font-size:0.75rem;color:#58a6ff'>🔗 NVD Reference</a>" if top_cve.get('reference') else ''}
    </div>
    """, unsafe_allow_html=True)

    # Additional CVEs
    if len(all_cves) > 1:
        with st.expander(f"Show all {len(all_cves)} CVEs for {cve_type}"):
            for cve in all_cves[1:]:
                score_c = cve.get('cvss_score','N/A')
                st.markdown(f"""
                <div style="background:#161b22;border:1px solid #30363d;border-radius:6px;
                            padding:10px;margin:6px 0;">
                  <b style="color:#f87171">{cve.get('cve_id','N/A')}</b>
                  <span style="margin-left:8px;color:#fbbf24">CVSS {score_c}</span><br/>
                  <small style="color:#8b949e">{cve.get('description','')[:120]}...</small>
                </div>
                """, unsafe_allow_html=True)

    # Trending alert
    st.markdown("<br/>", unsafe_allow_html=True)
    if log_data:
        last = st.session_state.last_attack
        if last and last.get("attack_type") == cve_type:
            cve_hint = last.get("cve_hints", [""])[0]
            st.markdown(f"""
            <div style="background:#1c1407;border:1px solid #f97316;border-radius:8px;padding:12px">
              <div style="color:#f97316;font-weight:700">⚠️ Active Threat Match</div>
              <div style="color:#e6edf3;margin-top:4px;font-size:0.85rem">
                Live attack from <b>{last.get('src_ip')}</b> matches pattern for
              </div>
              <div style="color:#fbbf24;font-weight:700;margin-top:4px">{cve_hint}</div>
              <div style="color:#8b949e;font-size:0.75rem;margin-top:4px">
                Confidence: {last.get('confidence',0)}%
              </div>
            </div>
            """, unsafe_allow_html=True)

    # Matched rules for last attack
    if log_data:
        relevant = [e for e in log_data if e.get("attack_type") == cve_type]
        if relevant:
            last_rel = relevant[-1]
            rules    = last_rel.get("matched_rules", [])
            if rules:
                st.markdown("<br/><small style='color:#8b949e'><b>Matched Signatures</b></small>", unsafe_allow_html=True)
                for rule in rules[:3]:
                    st.code(rule, language="regex")

# ─── Payload Inspector ────────────────────────────────────────────────────────

st.markdown("---")
st.markdown("### 🔬 Payload Inspector")

if log_data:
    latest = log_data[-1]
    atype  = latest.get("attack_type","-")
    type_color = {"SQLi":"#f87171","XSS":"#fbbf24","LFI":"#a78bfa","CMDi":"#f97316"}.get(atype,"#e6edf3")

    p1, p2 = st.columns([2, 1])
    with p1:
        st.markdown(f"**Last detected payload** — <span style='color:{type_color}'>{atype}</span>", unsafe_allow_html=True)
        st.code(latest.get("payload_snip", ""), language="http")
    with p2:
        st.markdown("**Auto-Defense Action**")
        action   = latest.get("action","PENDING")
        san_note = latest.get("sanitization","")
        st.markdown(f"""
        <div style="background:#0d1117;border:1px solid #22c55e;border-radius:6px;padding:12px">
          <div style="color:#22c55e;font-weight:700">✅ {action}</div>
          <div style="color:#8b949e;font-size:0.82rem;margin-top:6px">{san_note}</div>
          <div style="color:#8b949e;font-size:0.82rem;margin-top:6px">
            IP: <span style="color:#f87171">{latest.get('src_ip')}</span> → DROPPED
          </div>
        </div>
        """, unsafe_allow_html=True)
else:
    st.markdown("<small style='color:#8b949e'>No payload data yet. Simulate an attack to inspect.</small>", unsafe_allow_html=True)

# ─── Footer ───────────────────────────────────────────────────────────────────

st.markdown("---")
st.markdown("""
<div style="text-align:center;color:#8b949e;font-size:0.8rem">
  AutoShield AI — Hackathon Edition &nbsp;|&nbsp;
  Scapy + ML + iptables + NVD CVE API &nbsp;|&nbsp;
  <span style="color:#22c55e">●</span> System Active
</div>
""", unsafe_allow_html=True)
